﻿import { useState } from 'react';
import { ArrowLeft, Gamepad2 } from 'lucide-react';
import { BuildTheBlockGame } from './components/BuildTheBlockGame';

export default function App() {
  const [playing, setPlaying] = useState(false);

  if (playing) {
    return (
      <div className="min-h-screen bg-[#081d38]">
        <header className="border-b border-[#dfa62a] px-4 py-3 text-white">
          <button type="button" onClick={() => setPlaying(false)} className="inline-flex items-center gap-2 rounded-lg bg-white/10 px-4 py-2 text-sm font-bold hover:bg-white/20">
            <ArrowLeft className="h-4 w-4" /> Game Hub
          </button>
        </header>
        <main className="mx-auto w-full max-w-[1500px] p-3 sm:p-6">
          <BuildTheBlockGame />
        </main>
      </div>
    );
  }

  return (
    <main className="min-h-screen bg-[#081d38] px-3 py-5 sm:px-6 sm:py-8">
      <div className="mx-auto max-w-[1500px]">
        <button
          type="button"
          onClick={() => setPlaying(true)}
          aria-label="Start the current Discovery Exchange Game"
          className="group block w-full overflow-hidden rounded-2xl border-2 border-[#dfa62a] bg-[#081d38] p-0 shadow-2xl outline-none focus-visible:ring-4 focus-visible:ring-[#fcd34d]"
        >
          <img src="/assets/discovery-exchange-game-hub-preview.jpg" alt="The Discovery Exchange Game Hub preview" className="block h-auto w-full transition-transform duration-300 group-hover:scale-[1.01]" />
          <span className="flex items-center justify-center gap-3 bg-gradient-to-r from-amber-500 to-yellow-300 px-4 py-4 text-lg font-black text-[#081d38] sm:text-2xl">
            <Gamepad2 className="h-6 w-6" /> Open Game 1: Build the Block
          </span>
        </button>
        <p className="mx-auto mb-0 mt-4 max-w-3xl text-center text-sm leading-relaxed text-slate-200">
          The image is a visual Game Hub preview. The button opens the included playable Game 1. The pictured progress, leaderboard, rewards, and other modes are artwork, not active features in this package.
        </p>
      </div>
    </main>
  );
}

