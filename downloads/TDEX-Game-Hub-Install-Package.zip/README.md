﻿# TDEX Game Hub — small install handoff

This standalone package contains the current interactive **Game 1: Build the Block**, its how-to-play modal, and the provided Game Hub preview artwork.

## Install and run

1. Install Node.js 20 or newer.
2. Extract this ZIP and open a terminal in the extracted folder.
3. Run `npm install`.
4. Run `npm run dev` and open the local URL Vite prints.
5. Run `npm run build` to create a production build in `dist/`.

## Scope

The hub artwork is a static visual preview. Clicking it opens the included playable Game 1. The stats, leaderboard, rewards, and other game modes shown in the artwork are not active features in this handoff.

Game files: `src/components/BuildTheBlockGame.tsx` and `src/components/HowToPlayWalkthroughModal.tsx`.
